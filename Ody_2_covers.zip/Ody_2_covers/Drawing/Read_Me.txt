The xxx.fpd files sgould open with the Front Panel Designer

https://www.frontpanelexpress.com/downloads/front_panel_designer/?no_cache=1