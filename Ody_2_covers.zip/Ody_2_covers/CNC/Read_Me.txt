These G-codes are intended only for plastic working.

The contour and OLED milling are doing with a 2mm End Mill Cutter.
The holes end engraving are doing with a V-shape 20 DEG 0.2mm Mill Cutter.

The best material plastic - LZ993M  https://www.johnsonplastics.com/ipi-laserables-matte-smooth-silver-black-1-16-engraving-plastic